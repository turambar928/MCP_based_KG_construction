REVIEW DRAFT — not yet cleared for submission.
Read REVIEW_STATUS.json before use.
Compile main.tex from this directory. See repository experiment READMEs for data and results.
