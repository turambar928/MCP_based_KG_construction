# Overleaf 最小修复

只需把 tables/offline_loop_ceiling.tex 上传到项目根目录的 tables 文件夹，保持文件名不变。然后选择 Recompile from scratch。无需更改 main.tex、编译器或模板。

这是前一更新包漏带的表格；原章节内容不需要再次替换。若完整编译后引用仍未定义，再检查 references.bib 与文献命令。Underfull 是排版警告。
